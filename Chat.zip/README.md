# COVID-19-Chatbot
A COVID 19 Chatbot for React apps. [Live Demo](https://9cluu.csb.app/)

![COVID-19-ChatBot](https://user-images.githubusercontent.com/45126869/132464863-87b10d49-449e-4be8-8756-f2fc19f28a44.gif)

